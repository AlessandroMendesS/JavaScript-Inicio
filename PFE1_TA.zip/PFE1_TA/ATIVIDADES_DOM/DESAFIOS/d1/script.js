function aumentar () {
    let botao = document.getElementById('botao');
    
    let largura = botao.offsetWidth;
    let altura = botao.offsetHeight;

    botao.style.width = (largura * 2) + 'px';
    botao.style.height = (altura * 2) + 'px';

}
