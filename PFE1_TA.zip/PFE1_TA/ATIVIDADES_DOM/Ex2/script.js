// crie uma hierarquia da sua familia utilizando os conceitos de DOM

function destacarElemento () {
    const neto = document.getElementById('neto1');
    neto.style.color = 'blue';
}

