// crie uma funcao que calcule a soma de 2 numero passados via input
// ao clicar no botao o mesmo deve retornar o resultado.

function calcularSoma() {
   const num1 = parseFloat(document.getElementById('input1').value);
   const num2 = parseFloat(document.getElementById('input2').value);

   const soma = num1 + num2;

   const resultado = document.getElementById('resultado')
    resultado.textContent = "Resultado " + soma;
}