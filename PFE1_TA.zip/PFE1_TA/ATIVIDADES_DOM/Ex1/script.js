// Ex 1) criar uma função para alterar o conteudo de um paragrafo - criar um botao para isto...

function alterarTexto () {
    const paragrafo = document.getElementById('texto');
    paragrafo.textContent = 'Alessandro askduibgsaudyaswkjhd asjf'
}

const botao = document.getElementById('id');
botao.addEventListener('click',alterarTexto)
