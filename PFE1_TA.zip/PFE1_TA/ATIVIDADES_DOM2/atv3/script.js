const botao = document.getElementById('botao');
const lista = document.getElementById('lista');

botao.addEventListener('click', () => {
    let deleteItem = lista.lastElementChild;
    lista.removeChild(deleteItem)
})