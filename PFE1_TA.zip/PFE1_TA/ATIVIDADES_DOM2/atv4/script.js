const botao = document.getElementById('botao');
const conteudo = document.getElementById('conteudo');

botao.addEventListener('click', () => {
    conteudo.style.display = conteudo.style.display === 'none' ? 'block' : 'none';
    

})