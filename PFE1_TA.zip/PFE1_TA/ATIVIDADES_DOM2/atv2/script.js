// function addItem() {
//    let novoItem = document.createElement('li');
//    let textoItem = document.createTextNode('Novo Item');
//    novoItem.appendChild(textoItem)
//     let li = document.querySelector('#lista');
//     let pai = li.parentNode;
//     pai.appendChild(novoItem);
// }
// const botao = document.getElementById('botao')
// botao.addEventListener('click', addItem)

const botao = document.getElementById('botao');
const item = document.getElementById('lista')

botao.addEventListener('click', () => {
    let novoItem = document.createElement('li')
    novoItem.textContent = 'Novo Item';
    item.appendChild(novoItem);
})