
function pegarCor() {
    const letra = '0123456789ABCDEF';
    var cor = '#';
    for (i = 0; i < 6; i++) {
        cor = cor + letra[Math.floor( Math.random() * 16)];
        console.log(cor);
    }
    return cor;
}

setInterval( () => {
    document.body.style.backgroundColor = pegarCor();
},0.1)

