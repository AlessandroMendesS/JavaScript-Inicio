console.log(document.querySelector('#container-main h1'));
console.log(document.querySelector('#segundo-container h1'));
console.log(document.querySelector('#segundo-container h1'));
console.log(document.querySelector('div div p'));
console.log(document.querySelector('ul .itens-azuis'));