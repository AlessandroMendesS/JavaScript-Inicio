let itens = document.querySelectorAll('.itens-vermelhos');
itens[0].style.color = 'red';

let itens2 = document.querySelectorAll('.itens-vermelhos');
itens[1].style.color = 'blue';

let itens3 = document.querySelectorAll('.itens-vermelhos');
itens[2].style.color = 'yellow';





