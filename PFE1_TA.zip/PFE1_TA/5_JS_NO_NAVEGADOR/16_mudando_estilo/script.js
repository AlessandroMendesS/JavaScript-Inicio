let elemento = document.querySelector('#titulo-main');
setTimeout(function(){
 elemento.style.color = 'blue';
 elemento.style.backgroundColor = 'yellow';

},1000)