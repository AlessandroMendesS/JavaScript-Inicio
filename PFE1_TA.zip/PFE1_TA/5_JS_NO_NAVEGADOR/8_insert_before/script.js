let novoElemento = document.createElement("p"); //cria elemento <p>
let texto = document.createTextNode("Alessandro"); // cria conteudo dentro do <p>
novoElemento.appendChild(texto); // insere o conteudo dentro do <p>

let elementoAlvo = document.querySelector("#titulo-main");
let elementoPai = document.querySelector("#container-main");
elementoPai.insertBefore(novoElemento, elementoAlvo);
