
console.log(document.getElementById('titulo'));