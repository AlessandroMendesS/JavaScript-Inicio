let nome = 'Alessandro';
console.log(nome);
console.log(`O meu nome é: ${nome}`);

let laranjas = 5;
console.log(laranjas * laranjas);

// Subscreve a variavel nome
nome = "João";
console.log(nome);
// Subscreve a variavel laranjas
laranjas = 8974;
console.log(laranjas);

let um = 1, dois = 2, tres = 3;
console.log(um + dois + tres);

