let velocidade = 240;
if (velocidade <= 80) {
    console.log("Não foi multado!");
} else {    
    console.log("Foi multado");
    
    
}