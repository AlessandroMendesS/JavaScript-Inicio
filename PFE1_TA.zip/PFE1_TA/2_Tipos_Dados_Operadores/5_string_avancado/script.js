console.log('Primeira Linha \n Segunda Linha');
console.log("Meu nome é 'Alessandro' ");
console.log(`A multiplicacao de 5 por 3 é = ${5 * 3}`);
console.log('Oi ' + 'Meu ' + 'nome ' + 'é ' + ' Alessandro '  );
