console.log(typeof 5);
console.log(typeof 10.2);
console.log(typeof -123);
