let num = Number(1);
let num2 = Number(45);

console.log('Soma = ' + (num + num2));
console.log('Subtração = ' + (num - num2));
console.log('Multiplicação = ' + num * num2);
console.log('Divisão = ' + num / num2);
console.log('Resto = ' + (num % num2));

let x = 'Alessandro';
if (x == num) {
  console.log('Nao funciona ');
}
let y = true;
if (num2 === y) {
  console.log('Isso mesmo');
}

/*O == serve para verificar se algo (variavel) é igual a outra, já
 === é para compara o tipo da variavel e se têm os mesmos valores */

if (num || num2 == 5) {
  console.log('OU');
} // || -> OU
if (num && num2 == 3) {
  console.log('&&');
} // && -> E
if (num != num2) {
  console.log('Diferença');
} // != -> DIFERENÇA
