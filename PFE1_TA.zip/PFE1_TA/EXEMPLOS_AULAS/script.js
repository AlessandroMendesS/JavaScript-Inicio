// var titulo = document.getElementById('titulo');
// var conteudo = titulo.textContent;
// console.log(conteudo);

function alterarBg() {
    document.body.style.backgroundColor = '#161616';
}

const botao = document.getElementById('meuBotao');
botao.addEventListener('click',alterarBg);