let stringg = String('Alessandro');
let numberr = Number(9);
let booleann = Boolean(true);
let undefinedd = undefined;
let nulll = null;

console.log(typeof stringg);
console.log(typeof numberr);
console.log(typeof booleann);
console.log(typeof undefinedd);
console.log(typeof nulll);

