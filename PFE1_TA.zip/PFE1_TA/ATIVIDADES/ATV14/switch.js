// a)
let numero = Number(prompt('Digite um numero de 1 a 7'));
switch (numero) {
  case 1:
    console.log('Domingo');
    break;
  case 2:
    console.log('Segunda');
    break;
  case 3:
    console.log('Terça');
    break;
  case 4:
    console.log('Quarta');
    break;
  case 5:
    console.log('Quinta');
    break;
  case 6:
    console.log('Sexta');
    break;
  case 7:
    console.log('Sábado');
    break;
  default:
    console.log('Digite numero de 1 a 7.');
    break;
}

// b)
let cor = prompt('Escolha (Azul, Verde, Vermelho): ');
switch (cor) {
  case 'azul':
    console.log('Azullllllllllllllll 🔵📘🩵');
    break;
  case 'vermelho':
    console.log('Amorrrrr !!!!! ❤️ ');
    break;
  case 'verde':
    console.log('Grama 🍏📗🥗');
    break;
  default:
    console.log("ESCOLHA APENAS AZUL, VERMELHO OU VERDE ");
    break;
}
