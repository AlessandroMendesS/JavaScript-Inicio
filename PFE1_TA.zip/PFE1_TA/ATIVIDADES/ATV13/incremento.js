// a)
for (let cont = 1; cont <= 10; cont++) {
  console.log(cont);
}

// // b)
for (let cont = 10; cont >= 1; cont--) {
    console.log(cont);
  }

