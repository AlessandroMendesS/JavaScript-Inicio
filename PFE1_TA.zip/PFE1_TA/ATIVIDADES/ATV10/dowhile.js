// a)
do {
    var num = Number(prompt('Digite um numero (0 para mostrar o dobro do numero): '));
    console.log(num*2);
} while (num != 0);

// b)

do {
    var nome = prompt("Digite seu nome:")
    console.log(nome);
} while (nome != "sair");

