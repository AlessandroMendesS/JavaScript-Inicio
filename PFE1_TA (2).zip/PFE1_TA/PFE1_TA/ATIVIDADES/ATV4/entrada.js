// a)
let nome = prompt("Qual o seu nome?");
console.log(`Bem Vindo(a) ${nome}`);

// b)
let num1 = prompt("Digite um numero");
let num2 = prompt("Digite outro numero");
var resultado = Number(num1) + Number(num2);

console.log(`A soma do numero ${num1} com o numero ${num2} é: ${resultado} `);
