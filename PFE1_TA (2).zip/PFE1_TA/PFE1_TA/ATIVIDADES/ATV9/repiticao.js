// a)
let i = 1;
while (i <= 10) {
  console.log(i++);
}

// b)
let s = Number(prompt('Digite a senha: '));
while (s != 1234) {
  s = Number(prompt('Digite a senha: '));
  if (s == 1234) {
    alert('Digitou 1234 !!!');
    break;
  }
}
