// a)
for (let num = 2; num <= 20; num += 2) {
  console.log(num);
}

// b)
let numero = Number(prompt('Digite um numero para saber sua tabuada: '));
for (let contador = 0; contador <= 10; contador++) {
  console.log(numero + ' x ' + contador + ' = ' + numero * contador);
}
