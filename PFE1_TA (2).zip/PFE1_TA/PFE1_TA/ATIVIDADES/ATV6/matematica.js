// a)

let aleat = Math.ceil(Math.random(1, 100) * 100)
console.log(aleat);

// b)

let numero = prompt("Digite um numero para saber sua raiz quadrada: ")
console.log(Math.sqrt(numero));




