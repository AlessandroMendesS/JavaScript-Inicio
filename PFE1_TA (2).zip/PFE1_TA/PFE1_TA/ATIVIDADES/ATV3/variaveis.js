// a)
var variavel1 = 10;
const variavel2 = 20; // Assignment to constant variable.
let variavel3 = 30;

// reatribuindo valores a variavel
variavel1 = 100;
variavel2 = 200; // Assignment to constant variable.
variavel3 = 300;

console.log(variavel1, variavel3);

// b)
for (let i = 0; i < 10; i++) {
}
console.log(i);

// não é possivel acessar o i fora do for, deveria estar dentro do for
