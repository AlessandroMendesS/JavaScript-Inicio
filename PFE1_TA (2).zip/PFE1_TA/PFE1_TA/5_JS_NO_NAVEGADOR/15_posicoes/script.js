let elemento = document.querySelector('#titulo-main');
console.log(elemento.getBoundingClientRect());