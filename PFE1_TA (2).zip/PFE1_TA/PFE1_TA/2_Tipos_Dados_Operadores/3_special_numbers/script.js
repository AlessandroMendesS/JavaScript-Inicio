console.log(typeof (2 + 3));
console.log(typeof (5 - 12));
console.log(typeof (4 * 4));
console.log(typeof (5 / 3));
// resto 0
console.log(20 % 2);
// resto 1  
console.log(21 % 2);
