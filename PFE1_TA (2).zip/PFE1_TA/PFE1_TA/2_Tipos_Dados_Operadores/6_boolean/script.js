console.log(typeof true);
console.log(typeof false);
console.log(10 > 2);
console.log(typeof (5 > 200));


