// a)

for (let num = 1; num <= 10; num++) {
  console.log(num);
  if (num == 5) {
    break;
  }
}

// b)

for (let num = 1; num <= 10; num++) {
  if (num % 2 == 0) {
    console.log(num);
    continue;
  }
}
