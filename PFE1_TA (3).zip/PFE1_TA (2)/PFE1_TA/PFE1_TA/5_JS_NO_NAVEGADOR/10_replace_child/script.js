let novoElemento = document.createElement('p');
let texto = document.createTextNode('Isso aqui é top!');
novoElemento.appendChild(texto);

let heading = document.querySelector('#titulo-main');
let paiHeading = heading.parentNode;
paiHeading.replaceChild(novoElemento, heading);