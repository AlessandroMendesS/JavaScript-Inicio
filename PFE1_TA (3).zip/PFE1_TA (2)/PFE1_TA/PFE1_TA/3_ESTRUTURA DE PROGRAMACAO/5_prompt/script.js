let idade = prompt('Qual a sua idade: log');
console.log(idade);
let nome = prompt("Qual seu nome: ")
console.log(nome);

